(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').addClass('shadow-sm').css('top', '0px');
        } else {
            $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // // Facts counter
    // $('[data-toggle="counter-up"]').counterUp({
    //     delay: 10,
    //     time: 2000
    // });


    // // Testimonials carousel
    // $(".testimonial-carousel").owlCarousel({
    //     autoplay: true,
    //     smartSpeed: 1000,
    //     items: 1,
    //     dots: false,
    //     loop: true,
    //     nav: true,
    //     navText : [
    //         '<i class="bi bi-chevron-left"></i>',
    //         '<i class="bi bi-chevron-right"></i>'
    //     ]
    // });
    
    const btnCrop = document.querySelectorAll(".btn-crop");
    const area = document.querySelector("#area");       
    const page = document.querySelector(".page");
    const possibleArea = {
        "토마토" : ["나주시","고흥군","장성군","화순군","담양군","광양시"],    
        "딸기" : ["나주시", "장흥군", "영광군", "보성군","곡성군","담양군","화순군", "강진군"],
        "고구마" : ["무안군", "영암군", "해남군", "영광군"],
        "고추" : ["고흥군", "진도군", "함평군"],
        "대파" : ["진도군"],
        "마늘" : ["고흥군", "함평군", "무안군", "여수시"],
        "복숭아" : ["화순군", "순천시"],
        "쌀" : ["고흥군", "완도군", "무안군", "영암군", "해남군", "화순군"],
        "양파" : ["고흥군", "영광군", "함평군", "여수시", "무안군"],
        "오이" : ["고흥군", "구례군", "순천시"],
        "키위" : ["고흥군", "보성군"],
        "파" : ["진도군"],
        "포도" : ["장성군", "담양군"],
        "시금치" :["신안군"],
        "쪽파" : ["보성군"]
    };    
    const cropInfo = {
        "토마토" : ["토마토.jpg"],
        "딸기" : ["딸기.jpg"],
        "고구마" : ["고구마.jpg"],
        "고추" : ["고추.jpg"],
        "대파" : ["대파.jpg"],
        "마늘" : ["마늘.jpg"],
        "복숭아" : ["복숭아.jpg"],
        "쌀" : ["쌀.jpg"],
        "양파" : ["양파.jpg"],
        "오이" : ["오이.jpg"],
        "키위" : ["키위.jpg"],
        "파" : ["파.jpg"],
        "포도" : ["포도.jpg"],
        "시금치" : ["시금치.jpg"],
        "쪽파" : ["쪽파.jpg"],
    }
    btnCrop.forEach((item) => {
    item.addEventListener("click", (e)=>{   
    area.innerHTML = "";
    for(let key in possibleArea){    
        if(item.value==key){ 
            for(let i=0; i<possibleArea[key].length; i++){ 
                const newRow = area.insertRow();
                const newCell = newRow.insertCell();   
                const newButton = document.createElement("input");
                newButton.setAttribute("type", "button");    
                newButton.classList.add("btn-area", "btn");                             
                newButton.setAttribute("value",possibleArea[key][i]);   
                newButton.textContent = possibleArea[key][i];
                newCell.appendChild(newButton); 
            }
            let areaButtons = document.querySelectorAll(".btn-area");
            let activedValue; 
            areaButtons.forEach((item)=>{
                item.addEventListener("click",(e)=>{
                    activedValue=e.target.value;
                    console.log(activedValue);
            }) 
            })
            for(let n=0; n<cropInfo[key].length; n++){                
            page.innerHTML=`<div class="page-content page-container" id="page-content"> <div class="row">  <div class="card"> <div class="card-header"><strong>${(item.value)}의 수확량</strong></div> <div class="card-body"> </div>`;               
        const cardBody = document.querySelector(".card-body"); 
        cardBody.innerHTML="";
        const img = new Image();              
        img.src= `img/${cropInfo[key][n]}`;
        cardBody.appendChild(img); 
        }
    }
    }    
    });
    })
    const modal = document.querySelector(".modal-button");
        modal.addEventListener("click", ()=>{ 
        let radioButtons = document.querySelectorAll('input[type="radio"]');
        let checkedValue;      
        radioButtons.forEach(radioButton =>{
            if(radioButton.checked){
                checkedValue = radioButton.value;
            }
        })  
        if(checkedValue=="토마토"){ 
            $(".crop").hide();
            $(".tomato").show();
        }else if(checkedValue=="딸기"){ 
            $(".crop").hide();
            $(".stberry").show();   
        }else if(checkedValue=="파"){
            $(".crop").hide();
            $(".greenonion").show(); 
        }else if(checkedValue=="오이"){
            $(".crop").hide();
            $(".cucumber").show(); 
        }else if(checkedValue=="양파"){
            $(".crop").hide();
            $(".onion").show(); 
        }else if(checkedValue=="복숭아"){
            $(".crop").hide();
            $(".peach").show(); 
        }else if(checkedValue=="고추"){
            $(".crop").hide();
            $(".pepper").show(); 
        }else if(checkedValue=="키위"){
            $(".crop").hide();
            $(".kiwi").show(); 
        }else if(checkedValue=="쌀"){
            $(".crop").hide();
            $(".rice").show(); 
        }else if(checkedValue=="마늘"){
            $(".crop").hide();
            $(".garlic").show(); 
        }else if(checkedValue=="고구마"){
            $(".crop").hide();
            $(".spotato").show(); 
        }else if(checkedValue=="시금치"){
            $(".crop").hide();
            $(".spinach").show(); 
        }else if(checkedValue=="쪽파"){
            $(".crop").hide();
            $(".chives").show(); 
        }else if(checkedValue=="포도"){
            $(".crop").hide();
            $(".grape").show(); 
        } 
    }); 
})(jQuery);
