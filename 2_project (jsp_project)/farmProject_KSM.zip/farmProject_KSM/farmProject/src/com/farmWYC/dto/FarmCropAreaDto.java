package com.farmWYC.dto;

public class FarmCropAreaDto {
//	int crop_num;
	String crop_name;
	String crop_eng;
	String crop_area;
	String area_eng;
	String area_name;

	
	public String getArea_eng() {
		return area_eng;
	}

	public void setArea_eng(String area_eng) {
		this.area_eng = area_eng;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public FarmCropAreaDto() {
	}
	
	public FarmCropAreaDto(String area_eng, String area_name) {
		this.area_eng = area_eng;
		this.area_name = area_name;
	}
	
	public FarmCropAreaDto(String crop_name, String crop_eng, String crop_area) {
		this.crop_name = crop_name;
		this.crop_eng = crop_eng;
		this.crop_area = crop_area;
	}
	
//	public FarmCropAreaDto(String crop_area1, String crop_area2, String crop_area3, String crop_area4, String crop_area5, String crop_area6, String crop_area7, String crop_area8) {
//		this.crop_area1 = crop_area1;
//		this.crop_area1 = crop_area2;
//		this.crop_area1 = crop_area3;
//		this.crop_area1 = crop_area4;
//		this.crop_area1 = crop_area5;
//		this.crop_area1 = crop_area6;
//		this.crop_area1 = crop_area7;
//		this.crop_area1 = crop_area8;
//	}
//	
//	public FarmCropAreaDto(int crop_num, String crop_name, String crop_eng, String crop_area1, String crop_area2, String crop_area3, String crop_area4, String crop_area5, String crop_area6, String crop_area7, String crop_area8) {
//		this.crop_num = crop_num;
//		this.crop_name = crop_name;
//		this.crop_eng = crop_eng;
//		this.crop_area1 = crop_area1;
//		this.crop_area1 = crop_area2;
//		this.crop_area1 = crop_area3;
//		this.crop_area1 = crop_area4;
//		this.crop_area1 = crop_area5;
//		this.crop_area1 = crop_area6;
//		this.crop_area1 = crop_area7;
//		this.crop_area1 = crop_area8;
//	}

//	public int getCrop_num() {
//		return crop_num;
//	}
//
//	public void setCrop_num(int crop_num) {
//		this.crop_num = crop_num;
//	}

	public String getCrop_name() {
		return crop_name;
	}

	public void setCrop_name(String crop_name) {
		this.crop_name = crop_name;
	}

	public String getCrop_eng() {
		return crop_eng;
	}

	public void setCrop_eng(String crop_eng) {
		this.crop_eng = crop_eng;
	}

	public String getCrop_area() {
		return crop_area;
	}

	public void setCrop_area(String crop_area) {
		this.crop_area = crop_area;
	}
	
	

//	public String getCrop_area1() {
//		return crop_area1;
//	}
//
//	public void setCrop_area1(String crop_area1) {
//		this.crop_area1 = crop_area1;
//	}
//
//	public String getCrop_area2() {
//		return crop_area2;
//	}
//
//	public void setCrop_area2(String crop_area2) {
//		this.crop_area2 = crop_area2;
//	}
//
//	public String getCrop_area3() {
//		return crop_area3;
//	}
//
//	public void setCrop_area3(String crop_area3) {
//		this.crop_area3 = crop_area3;
//	}
//
//	public String getCrop_area4() {
//		return crop_area4;
//	}
//
//	public void setCrop_area4(String crop_area4) {
//		this.crop_area4 = crop_area4;
//	}
//
//	public String getCrop_area5() {
//		return crop_area5;
//	}
//
//	public void setCrop_area5(String crop_area5) {
//		this.crop_area5 = crop_area5;
//	}
//
//	public String getCrop_area6() {
//		return crop_area6;
//	}
//
//	public void setCrop_area6(String crop_area6) {
//		this.crop_area6 = crop_area6;
//	}
//
//	public String getCrop_area7() {
//		return crop_area7;
//	}
//
//	public void setCrop_area7(String crop_area7) {
//		this.crop_area7 = crop_area7;
//	}
//
//	public String getCrop_area8() {
//		return crop_area8;
//	}
//
//	public void setCrop_area8(String crop_area8) {
//		this.crop_area8 = crop_area8;
//	}
	
	
}
